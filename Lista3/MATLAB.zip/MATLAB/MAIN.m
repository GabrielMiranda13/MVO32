clear all
close all
clc

global g
global aircraft

g = 9.80665;

aircraft = struct('S',260,'c',6.6,'b',44.8,...
    'm',130000,'Ixx',6.011e6,'Iyy',10.53e6,...
    'Izz',15.73e6,'Ixz',0.33e6,...
    'i_p_deg',2.17,'x_p',7.50,'z_p',2.65,...
    'Tmax',452000,'n_rho',0.8);

psidot_deg_s_eq = 0;

trim_par(1) = struct('V',77,'h',600,'gamma_deg',-3,...
    'thetadot_deg_s',0,'psidot_deg_s',psidot_deg_s_eq);
trim_par(2) = struct('V',131.5,'h',3000,'gamma_deg',0,...
    'thetadot_deg_s',0,'psidot_deg_s',psidot_deg_s_eq);
trim_par(3) = struct('V',264,'h',10000,'gamma_deg',0,...
    'thetadot_deg_s',0,'psidot_deg_s',psidot_deg_s_eq);

% Xtest = [250
%     2
%     5
%     5
%     5000
%     0
%     2
%     10
%     10
%     15
%     10
%     0];
% Utest = [0.5; -5; 5; 10; 15];
% [Xdot_test,Y_test] = dynamics(0,Xtest,Utest,3)

% https://www.mathworks.com/help/optim/ug/tolerances-and-stopping-criteria.html
options = optimset('Display','iter','TolX',1e-10,'TolFun',1e-10);
% % Em vers�es mais novas, pode ser necess�rio utilizar o seguinte:
% options = optimoptions(@fsolve,'Display','iter','StepTolerance',1e-10,'FunctionTolerance',1e-10);
% % ou:
% options = optimoptions(@fsolve,'Display','iter','TolX',1e-10,'TolFun',1e-10);

%--------------------------------------------------------------------------
% Trimmed flight conditions:

trim_output(3) = struct('X_eq',zeros(12,1),'U_eq',zeros(5,1),...
    'Y_eq',zeros(9,1));

for flag_cond=1:3
    x_eq_0 = zeros(12,1);
    x_eq_0(1) = trim_par(flag_cond).V;
    x_eq = fsolve(@trim_function,x_eq_0,options,trim_par,flag_cond);
    [~,X_eq,U_eq,Y_eq] = trim_function(x_eq,trim_par,flag_cond);
    
    trim_output(flag_cond).X_eq = X_eq;
    trim_output(flag_cond).U_eq = U_eq;
    trim_output(flag_cond).Y_eq = Y_eq;

    fprintf('----- A%d FLIGHT CONDITION -----\n\n',flag_cond);
    fprintf('   %-10s = %10.4f %-4s\n','gamma',trim_par(flag_cond).gamma_deg,'deg');
    fprintf('   %-10s = %10.4f %-4s\n','theta_dot',trim_par(flag_cond).thetadot_deg_s,'deg/s');
    fprintf('   %-10s = %10.4f %-4s\n','psi_dot',trim_par(flag_cond).psidot_deg_s,'deg/s');
    fprintf('\n');
    fprintf('   %-10s = %10.2f %-4s\n','V',X_eq(1),'m/s');
    fprintf('   %-10s = %10.4f %-4s\n','alpha',X_eq(2),'deg');
    fprintf('   %-10s = %10.4f %-4s\n','q',X_eq(3),'deg/s');
    fprintf('   %-10s = %10.4f %-4s\n','theta',X_eq(4),'deg');
    fprintf('   %-10s = %10.1f %-4s\n','h',X_eq(5),'m');
    fprintf('\n');
    fprintf('   %-10s = %10.4f %-4s\n','beta',X_eq(7),'deg');
    fprintf('   %-10s = %10.4f %-4s\n','phi',X_eq(8),'deg');
    fprintf('   %-10s = %10.4f %-4s\n','p',X_eq(9),'deg/s');
    fprintf('   %-10s = %10.4f %-4s\n','r',X_eq(10),'deg/s');
    fprintf('   %-10s = %10.4f %-4s\n','psi',X_eq(11),'deg');
    fprintf('\n');
    fprintf('   %-10s = %10.2f %-4s\n','throttle',U_eq(1)*100,'%');
    fprintf('   %-10s = %10.2f %-4s\n','Thrust',Y_eq(2),'N');
    fprintf('   %-10s = %10.4f %-4s\n','i_t',U_eq(2),'deg');
    fprintf('   %-10s = %10.4f %-4s\n','delta_e',U_eq(3),'deg');
    fprintf('   %-10s = %10.4f %-4s\n','delta_a',U_eq(4),'deg');
    fprintf('   %-10s = %10.4f %-4s\n','delta_r',U_eq(5),'deg');
    fprintf('\n');
    fprintf('   %-10s = %10.4f %-4s\n','Mach',Y_eq(3),'');
    fprintf('   %-10s = %10.4f %-4s\n','C_D',Y_eq(4),'');
    fprintf('   %-10s = %10.4f %-4s\n','C_L',Y_eq(5),'');
    fprintf('   %-10s = %10.4f %-4s\n','C_m',Y_eq(6),'');
    fprintf('\n');
    fprintf('   %-10s = %10.4f %-4s\n','C_Y',Y_eq(7),'');
    fprintf('   %-10s = %10.4f %-4s\n','C_l',Y_eq(8),'');
    fprintf('   %-10s = %10.4f %-4s\n','C_n',Y_eq(9),'');
    fprintf('\n');
end

%--------------------------------------------------------------------------
% Linearization around trimmed flight conditions:

lin_output(3) = struct('A',zeros(12,12),'B',zeros(12,5),...
    'C',zeros(9,12),'D',zeros(9,5));

step_val = 1e-5;

for flag_cond=1:3
    X_eq = trim_output(flag_cond).X_eq;
    Y_eq = trim_output(flag_cond).Y_eq;
    U_eq = trim_output(flag_cond).U_eq;
    
    A = zeros(length(X_eq),length(X_eq));
    C = zeros(length(Y_eq),length(X_eq));
    for j=1:length(X_eq)
        % 
    end
    
    B = zeros(length(X_eq),length(U_eq));
    D = zeros(length(Y_eq),length(U_eq));
    for j=1:length(U_eq)
        % 
    end
    
    lin_output(flag_cond).A = A;
    lin_output(flag_cond).B = B;
    lin_output(flag_cond).C = C;
    lin_output(flag_cond).D = D;
    
end
