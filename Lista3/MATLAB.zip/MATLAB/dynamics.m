function [Xdot,Y] = dynamics(t,X,U,flag_cond)

global g
global aircraft

V = X(1);
alpha_deg = X(2);
q_deg_s = X(3);
theta_deg = X(4);
h = X(5);
x = X(6);

beta_deg = X(7);
phi_deg = X(8);
p_deg_s = X(9);
r_deg_s = X(10);
psi_deg = X(11);
y = X(12);

throttle = U(1);
i_t_deg = U(2);
delta_e_deg = U(3);
delta_a_deg = U(4);
delta_r_deg = U(5);


%
%
%


Vdot = (u*udot + v*vdot + w*wdot)/V;
alphadot_rad_s = (u*wdot - w*udot)/(u^2 + w^2);
betadot_rad_s = (V*vdot - v*Vdot)/(V*sqrt(u^2 + w^2));

alphadot_deg_s = alphadot_rad_s*180/pi;
betadot_deg_s = betadot_rad_s*180/pi;


%
%
%


Xdot = [
    Vdot
    alphadot_deg_s
    qdot_deg_s_2
    thetadot_deg_s
    hdot
    xdot
    betadot_deg_s
    phidot_deg_s
    pdot_deg_s_2
    rdot_deg_s_2
    psidot_deg_s
    ydot
    ];

[CD,CY,CL,Cl,Cm,Cn] = aero_databank(X,U,flag_cond);

Y = [
    gamma_deg
    T
    Mach
    CD
    CL
    Cm
    CY
    Cl
    Cn
    ];
