figure(5)
plot3(X(:,12),X(:,6),X(:,5))
hold all
xlabel('y [m]')
ylabel('x [m]')
zlabel('h [m]')
axis equal